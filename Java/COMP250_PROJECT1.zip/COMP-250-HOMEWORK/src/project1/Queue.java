package project1;

import project1.Customer;


public class Queue {
//Declare head and tail for the queue, queue size starts at 0.
private Customer head;
private Customer tail;
private int qSize = 0;
private String lineName;


	//Constructor, Set head and tail to null for new queue. Also can give line a name
	public Queue(String name) {
		lineName = name;
		head = null;
		tail = null;
	}
	
	//Boolean to check if queue is empty to avoid Null Pointer Exceptions
	public boolean isEmpty() {
		if(head == null) {
			return true;
		}
		
		return false;
	}
	
	//Enqueue method for customers, also adds 1 to size of line when called.
	public void enqueue(Customer newCustomer) {
		Customer curr = this.head;
		
		if(curr == null) {
			head = newCustomer;
			tail = newCustomer;
		}
		

		else{
			tail.setNext(newCustomer);
			tail = newCustomer;
		}
		
		qSize++;
	}
	
	//Removes head from queue
	public void dequeue() {
		
		if(head != null){
			head = head.getNext();
		
			if(head == null) {
				tail = null;
			}
		}
	}
	
	//Getter for the head customer
	public Customer getHeader() {
		return this.head;
	}
	
	//Getter for size of line, used to pick optimal line.
	public int getSize() { 
		return qSize;
	}
	
	//Used to loop through the line and add 1 minute to each queued customers total wait time.
	public void incWaitTime() {
		Customer curr = this.head;
		
		while(curr != null) {
			curr.addWaitTime();
			curr = curr.getNext();
		}
	}
	
	//Print method to print Customer with ID and what time they arrived
	public void printList() {
		Customer curr = this.head;
		
		System.out.println("\n" + lineName + " | Customer ID | [Arrival Time] :\n");
		while(curr != null) {
			System.out.println(" Customer\t" + curr.getID() + "\t\t" + curr.getElapedTime() + "\n");
			curr = curr.getNext();
		}
	}
	
	//Getter for ID of head in a String. used when dequeuing 
	public String headID() {
		return head.getID();
		
	}
}
