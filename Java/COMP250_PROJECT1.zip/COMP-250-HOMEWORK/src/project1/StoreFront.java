package project1;

public class StoreFront {
// Create 3 lines 
Queue line1;
Queue line2;
Queue line3;
Queue optimal;			  // Holder for optimal line to enqueue into			
static int elapsedTime;
Customer waitingCustomer; // Created customer that has their arrival decremented

	//A new store front gets 3 lines, a waiting customer, and a default optimal line of line1.
	public StoreFront() {
		this.line1 = new Queue("Register 1");
		this.line2 = new Queue("Register 2");
		this.line3 = new Queue("Register 3");
		waitingCustomer = new Customer();
		this.optimal = line1;
		
	}
	
	
	//This does a lot, handles most things that need to be done every 1 minute cycle.
	public void cycle1Minute() {
		//eLapsedTime keeps track of arrival and departure times
		elapsedTime++;
		
		//Find the optimal line by calling the method from this class
		optimal = this.getOptimalLine();
		
		//Decrease service time for all customers at front of line.
		if(line1.isEmpty() == false)
			line1.getHeader().decService();		
		
		
		if(line2.isEmpty() == false) {
			line2.getHeader().decService();

		}
		if(line3.isEmpty() == false) {
			line3.getHeader().decService();
		}
		
		//Decrements the arrival time of the waiting customer
		waitingCustomer.decArrival();	
		
		//If the waiting customer arrival time hits 0, enqueue them into optimal line and print that line. Create a new waiting customer
		if(waitingCustomer.getArrivalTime() == 0) {
			optimal.enqueue(waitingCustomer);
			System.out.println("\nARRIVAL!!!!");
			optimal.printList();
			waitingCustomer = new Customer();
		}
		
		
		line1.incWaitTime();
		line2.incWaitTime();
		line3.incWaitTime();
	}
	public void dequeueLines() {	//if done being serviced, dequeue from that line.
		
		//Make sure line is empty and service time of head is 0, then print necessary info and dequeue. 
		if(line1.isEmpty() == false && line1.getHeader().getServiceTime() == 0){
			System.out.println("\nCustomer " + line1.headID() + "  left line 1 at: " + line1.getHeader().getElapedTime() + "  Spent: " + line1.getHeader().printWaitTime() + "\n");
			line1.dequeue();
			//line1.printList();
		}
		
		//Same as above for line 2
		if(line2.isEmpty() == false && line2.getHeader().getServiceTime() == 0){
			System.out.println("\nCustomer " + line2.headID() + "  left line 2 at: " + line2.getHeader().getElapedTime()+ "  Spent: " + line2.getHeader().printWaitTime()  + "\n");
			
			line2.dequeue();
			//line2.printList();
		}
		
		//Same
		if(line3.isEmpty() == false && line3.getHeader().getServiceTime() == 0){
			System.out.println("Customer " + line3.headID() + " left line 3 at: " + line3.getHeader().getElapedTime()+ "  Spent: " + line3.getHeader().printWaitTime()  +"\n");
			line3.dequeue();
			//line3.printList();
		}
	}
	
	//Method to find the optimal line for customer placement. (Line with least size is deemed 'optimal')
	public Queue getOptimalLine() {		//Figure out the best line to place customer in
		if(line1.getSize() > line2.getSize()) {
			return line2;
		}
		
		if(line2.getSize() > line3.getSize()) {
			return line3;
		}
				
		
		return line1;
		
	}	

	//Get elapsed time as a string
	public String getElapsedTime() {
		return Integer.toString(elapsedTime);
	}
}
