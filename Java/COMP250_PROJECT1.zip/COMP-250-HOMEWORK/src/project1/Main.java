package project1;

public class Main {


	public static void main(String[] args) {
		//Create a new grocery store
		StoreFront groceryStore = new StoreFront();
		
		//Set loop for how many minutes store is open
		for(int i = 0; i < 720; i++) {
			groceryStore.cycle1Minute(); // Cycles 1 minute
			groceryStore.dequeueLines(); // Checks all lines and dequeues necessary
			
		}		
	}
}
	
//1. Max customer in all lines at a time was 2. 1 customer in each line.

//2. Longest wait time for a customer was 8 minutes with the default timings.

/*3. With 2-5min arrival max customers was still 2. 1 customer in 2 lines. 
	  longest wait time shortened to 5 minutes. */

/*4. For arrival 1-4: 2 lanes to keep wait under 5 min. 1 lane to keep wait under 10 minutes
		 for arrival 2-5, 3 lanes needed to keep wait under 5 min. 2 lanes to keep under 10 min */