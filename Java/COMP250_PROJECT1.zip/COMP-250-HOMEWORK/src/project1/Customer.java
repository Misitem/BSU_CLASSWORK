package project1;

import java.util.Random;

public class Customer {
    static int elapsedTime;
	static int IDcount = 0;
    int customerID;
    int waitTime;
	int arrivalTime;
	int serviceTime;
	Customer next;
	
	private static int randomTime(int min, int max) {
		Random wait = new Random();
		
		return wait.nextInt((max - min)+1) + min;
	}
	
	public Customer() {
		this.waitTime = 0;
		this.arrivalTime = randomTime(1,4);
		this.serviceTime = randomTime(1,4);
		this.next = null;
		customerID = IDcount++;
		elapsedTime += this.arrivalTime;
	}
	
	public String getID() {
		return Integer.toString(customerID);
	}

	public Customer getNext() {
		return this.next;
	}

	public void setNext(Customer next) {
		this.next = next;
	}

	public void decArrival() {
		this.arrivalTime-=1;
	}
	
	public void decService() {
		this.serviceTime-=1;
	}
	public int getServiceTime() {
		return serviceTime;
	}
	
	public int getArrivalTime() {
		return arrivalTime;
	}
	
	public void addWaitTime() {
		this.waitTime++;
	}
	
	public String printWaitTime() {
		return Integer.toString(waitTime);
	}
	public String getElapedTime() {
		return Integer.toString(elapsedTime);
	}
}
