package lab2;

public class SortingAlgorithms2 {

	//method for quicksort, recursively partitions the array until done
	public static void quickSort(int[] arr, int low, int high) {
		
		if(low < high) {
			int p = partition(arr, low, high);
			quickSort(arr, low, p - 1);
			quickSort(arr, p + 1, high);
		}
	}
	
	
	// Set the pivot as last member of array and use the quicksort algorithm to sort
	public static int partition(int[] arr, int low, int high) {
		int pivot = arr[high];
		int i = low - 1;
		int j;
		
		//for the entire array, if that index is less than pivot, swap the 2
		for(j = low; j < high; j++) {
			
			if(arr[j] < pivot) {
				i = i+1;
				swap(arr, i, j);
			}
		}
		
		//if highest is lower than index i + 1, swap the high and that variable
		if(arr[high] < arr[i + 1]) {
			
			swap(arr, i+1, high);
		}
		return i + 1;
	}
	
	
	public static int[] mergeSort(int[] arr1, int[] arr2, int n) {
		//copy(arr1, 0, n, arr2);
		splitMergeSort(arr1, arr2 , 0, n);
		return arr1;
	}
	public static void splitMergeSort(int[] arr1, int[] arr2, int start, int end ) {
		
		if(end - start < 2) {
			return;
		}
		
		int mid = (end + start) / 2;
		
		splitMergeSort(arr1, arr2, start, mid);
		splitMergeSort(arr1, arr2, mid, end);
		
		merge(arr2, start, mid, end, arr1 );
	}
	
	public static void merge(int[] arr1, int start, int mid, int end, int[] arr2 ) {
		int i = start;
		int j = mid;
		
		for(int k = start; k < end; k++) {
			
			if(i < mid && (j >= end || arr1[i] <= arr1[j])) {
				arr2[k] = arr1[i];
				i = i + 1;
			}
			else {
				arr2[k] = arr1[j];
				j = j + 1;
			}
		}
	}
	
	public static void copy(int[] arr1, int start, int end, int[] arr2) {
		for(int k = start; k < end; k++) {
			arr2[k] = arr1[k];
		}
	}
	
	//Swap method to swap two given indexes of the given array
	public static void swap(int arr[], int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
		
	}
	
	
	
}
