package lab2;

import java.util.Arrays;

import lab1.SortingAlgorithms;

public class Main {

	public static void main(String[] args) {
		int arr1[] = {6,3,4,7,2,9,5,1,8,2};
		int arr2[] = {6,3,4,7,2,9,5,1,8,2};
		int arr3[] = arr2;
		
		
		System.out.println("Before quicksort: " + Arrays.toString(arr1));
		SortingAlgorithms2.quickSort(arr1, 0, 9);
		System.out.println("After quicksort: " + Arrays.toString(arr1));
		
		System.out.println();
		
		System.out.println("Before merge sort: " + Arrays.toString(arr2));
		SortingAlgorithms2.mergeSort(arr2, arr3, 0 );
		System.out.println("After merge sort: " + Arrays.toString(arr2));
	}
}

