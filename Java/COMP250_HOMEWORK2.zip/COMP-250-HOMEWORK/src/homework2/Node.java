package homework2;

public class Node<Type> {
	//next is a node of generic type, same for previous (< used for stack)
	private Node<Type> next;
	private Node<Type> previous;
	
	//Generic for the type of data to be stored
	private Type data;
	
	public Node() {
		this.next = null;
		this.previous = null;
	}
	//Used when inserting to the end, sets data type to input
	public Node(Type data) {
		this.data = data;
	}

	//Typical getNext for nodes, used mainly for looping through linked list
	public Node<Type> getNext() {
		return next;
	}

	//Typical setNext for nodes, sets the links
	public void setNext(Node<Type> next) {
		this.next = next;
	}

	//get and set previous used for stack
	public Node<Type> getPrevious(){
		return previous;
	}
	
	public void setPrevious(Node<Type> previous){
		this.previous = previous;
	}
	//Gets the data inside the node, type is generic, defined by the data
	public Type getData() {
		return data;
	}
}
