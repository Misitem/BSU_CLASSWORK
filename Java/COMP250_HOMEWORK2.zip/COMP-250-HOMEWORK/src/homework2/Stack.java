package homework2;
import homework2.Node;
import java.util.*;
public class Stack<Type> {

	private Node<Type> head;
	private Node<Type> tail;
	private int sSize = 0;
	
	public Stack() {
		//head = null;
		tail = null;
	}
	
	public void push(Node<Type> newData) {
			
		Node<Type> curr = this.tail;
		//If head is null then set new node to be head and tail.
		if(curr == null) {
			//head = newData;
			tail = newData;
		}
		//Otherwise, add new generic node to end list and set it as new tail
		else{
			newData.setPrevious(tail);
			//tail.setNext(newData);
			tail = newData;
		}
		sSize++;
	}
	
	public Type pop(){
		sSize--;
		if(isEmpty() == true) {
			throw new NoSuchElementException("Empty");
		}
		
		Node<Type> temp = tail;
		tail = temp.getPrevious();
		return temp.getData();
	}
	
	public boolean isEmpty() {
		if(tail == null) {
			return true;
		}
		return false;
	}
	
	public int getSize() {
		return sSize;
	}
}
