package homework2;
import homework2.Node;


public class LinkedList<Type> {

	//Head and tail for traversing and adding to list
	private Node<Type> head = null;
    private Node<Type> tail = null;
	
    //Constructor, sets head and tail to null as default.
	public LinkedList() {
		head = null;
		tail = null;
	}

	//Method for adding a new node of generic type
	public void addNode(Node<Type> newData) {
			Node<Type> curr = this.head;
			
			//If head is null then set new node to be head and tail.
			if(curr == null) {
				head = newData;
				tail = newData;
			}
			//Otherwise, add new generic node to end list and set it as new tail
			else{
				tail.setNext(newData);
				tail = newData;
			}
	}

	//Print out the list
	public void printList() {
		Node<Type> curr = this.head;

		while(curr != null) {
			System.out.print(curr.getData() + " -> ");
			curr = curr.getNext();
		}
	}
}
