package homework2;

import java.util.Scanner;
import homework2.LinkedList;
import homework2.Stack;
import homework2.Node;



public class Main {
	
	//static String compare = "";
	public static void main(String[] args) {
		
			//4 Different linked lists
			LinkedList<String> intList = new LinkedList<String>();
			LinkedList<String> doubleList = new LinkedList<String>();
			LinkedList<String> charList = new LinkedList<String>();
			LinkedList<String> strList = new LinkedList<String>();
			
			//Initializing input string
			String input = "";
			//For input reading
			Scanner scan = new Scanner(System.in);
			//Condition to end loop
			boolean end = false;
			
			while(end == false) {
				System.out.println("\n\nEnter something");
				input = scan.next();
				Node<String> currInput = new Node<String>(input);
				
				if(isInt(input) == true) {
					intList.addNode(currInput);
				}
				else if(isDbl(input) == true) {
					doubleList.addNode(currInput);
				}
				else if(isChar(input) == true) {
					charList.addNode(currInput);
				}
				else {
					strList.addNode(currInput);
				}

				System.out.print("\nDoubles: ");
				doubleList.printList();
				
				System.out.print("\nIntegers: ");
				intList.printList();
				
				System.out.print("\nChars: ");
				charList.printList();
				
				System.out.print("\nStrings: ");
				strList.printList();
				
				//If input is -1, end loop
				if(input.equals("-1")) {
					// This was causing problems, fixed by not closing until palindrome checker was done
					//scan.close();
					end = true;
				
				}
			}
	

/*			
	   PALINDROME CHECKER BELOW. ONLY RUNES ONCE PER MAIN
																*/
			Scanner pScan = new Scanner(System.in);
			
			//String that the stack will build upon when outputting
			String compare = "";
			//New stack of type character
			Stack<Character> inputStack = new Stack<Character>();
			//String for holding input
			String palinInput = "";
			//Used for looping through input
			Node<Character> nextChar;
			
			System.out.println("\n\nPalindrome Checker!! \n\nEnter a word");
			palinInput = pScan.next();
			
			//Loops through input for its entire length and adds the char at each index onto the stack
			for(int i=0; i < palinInput.length(); i++) {
				nextChar = new Node<Character>(palinInput.charAt(i));
				inputStack.push(nextChar);
			}
			
			//While the input stack is not empty, pop off the top and add it to the compare string
			//This results in the reverse of the input
			while(inputStack.isEmpty() == false) {
				compare += inputStack.pop();
			}
			
			
			//See if the input string and the string reversed using the stack match
			if(compare.equals(palinInput)) {
				System.out.println("This is a Palindrome");
			} else {
				System.out.println("NOT a Palindrome");
			}
			
			//Close Scanner
			pScan.close();
			
			//Below was just used for testing
			//System.out.println(compare);
			//System.out.println(palinInput);
	}
	
	
	
	//Method to see if input is a double
	public static boolean isDbl(String string) {
	   //Try to parse a Double, if you cant its not a double, otherwise it is
		try {
	        double inp = Double.parseDouble(string);
	    } catch (NumberFormatException e) {
	        return false;
	    }
	    return true;
	}
	
	//To see if input is integer
	public static boolean isInt(String string) {
		//Same as double
	    try {
	        double inp = Integer.parseInt(string);
	    } catch (NumberFormatException e) {
	        return false;
	    }
	    return true;
	}
	
	//To see if input is Char (String with length of 1)
	public static boolean isChar(String string) {
		if(string.length() == 1) {
			return true;
		}
		return false;
	}
	//Defaults to string so no checker need	
}