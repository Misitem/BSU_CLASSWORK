package lab1;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		int arr1[] = {6,3,4,7,2,9,5,1,8,2};
		int arr2[] = {6,3,4,7,2,9,5,1,8,2};
		
		System.out.println("Before insertion: " + Arrays.toString(arr1));
		SortingAlgorithms.insertionSort(arr1);
		System.out.println("After insertion: " + Arrays.toString(arr1));
		
		System.out.println();
		
		System.out.println("Before selection: " + Arrays.toString(arr2));
		SortingAlgorithms.selectionSort(arr2);
		System.out.println("After selection: " + Arrays.toString(arr2));
	}
}
