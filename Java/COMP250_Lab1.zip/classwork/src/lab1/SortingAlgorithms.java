package lab1;

public class SortingAlgorithms {
	
	
	public static void insertionSort(int[] arr) {
		//Initialize i at 1
		int i = 1;
		
		//while i is less than the array length, j gets i
		while(i < arr.length) {
			int j = i;
			
			//nested while, j > 0 and number before index of j is greater than index at j, swap the 2 and j gets the lesser
			while(j > 0 && arr[j-1] > arr[j]) {
				swap(arr, j, j-1);
				j = j-1;
			
			}
		
			// increment i by 1
			i = i + 1;
		}
	}
	
	
	
	public static void selectionSort(int arr[]) {
		//Initialize i, j for looping and set n to array length
		int i;
		int j;
		int n = arr.length;
		
		//small is the current minimum
		
		//loop through entire array and set the smallest to be the smallest number
		for(j = 0;  j < n-1; j++) {
			int small = j;
			
			//If the current element is less than j, than its the new smallest, get its index
			for(i = j+1; i < n; i++)
				if( arr[i] < arr[small]) {
					small = i;
				}
			
				//Swap j and current smallest
				swap(arr, j, small);
			
		}
	}
	
	
	public static void swap(int arr[], int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
		
	}
}
