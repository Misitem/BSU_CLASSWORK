package homework3;

public class Main {

	public static void main(String[] args) {
		
		// Tests for binary search tree
		 	
		BinarySearchTree tree = new BinarySearchTree();
	
		//Adding to tree
		tree.addNode(3);
        tree.addNode(2);
        tree.addNode(1);
        tree.addNode(4);
        tree.addNode(5);
        tree.addNode(6);
        tree.addNode(7);
 
        //Testing print orders
        System.out.println("\nIn Order:");
        tree.printInOrder();
        
        System.out.println("\nPre-Order:");
        tree.printPreOrder();
        
        System.out.println("\nPost-Order:");
        tree.printPostOrder();
        
        System.out.println("\nReverse Order:");
        tree.printReverseOrder();
        
        //Test to see if number is in tree (search)
        if(tree.searchTree(5)==true) {
        	System.out.println("\nThis number exists in the tree");
        }
        else { System.out.println("\nNumber not found in tree");
        }
        
        System.out.println("\nMin is: " + tree.findMin());
        
        System.out.println("\nMax is: " + tree.findMax());
	
	// Test for Radix Sort
        
  
    }
}
	
	

