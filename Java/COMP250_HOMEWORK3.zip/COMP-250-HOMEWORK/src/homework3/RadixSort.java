package homework3;

//import java.lang.Math;
import java.util.ArrayList;
import java.util.List;

public class RadixSort {
	
	//int digit;
	int[] tempArr;
	int maxval;
	int tempBase;
	
	 public List<Integer>[] list_to_buckets(int[] arr, int base, int iteration) {
		 tempBase = base;
		 tempArr = arr;
		 /**Create an integer list of buckets the size of base then create a bucket
		  * for each spot in the list of buckets
		  */
         List<Integer>[] buckets = new ArrayList[base];
         
         for (int i = 0; i < buckets.length; i++) {
             buckets[i] = new ArrayList<Integer>();
         }
         
         for(int number : arr) {
        	 int digit = (number / (base ^ iteration)) % base;
        	 
        	 buckets[digit].add(number);
         }
         return buckets;
	 }
	 
	 public Integer buckets_to_list(List<Integer>[] buckets){
		 
		 for(List<Integer> bucket : buckets) {
			 for(Integer number : bucket) {
				 return number;
			 }
		 }
		return null;
	 }
	 
	 //maxval = max(tempArray);
	 int it = 0;
	 
	 public Integer sort() {
		 while((tempBase^it) <= maxval) {
			 return buckets_to_list(list_to_buckets(tempArr, tempBase, it))
			 it+=1;
		 }
		 
	 }
}
 




