package homework3;



public class Node<Type> {
	
	//Nodes for left and right children
	public Node<Type> left;
	public Node<Type> right;

	//Generic type for your data (Can really only be Integer for this assignment)
	public Type data;
	
	public Node() {
		this.left = null;
		this.right = null;
	}
	
	//Constructor with specific data
	public Node(Type data) {
		this.data = data;
		this.left = null;
		this.right = null;
	}
	
	public Type getData() {
		return this.data;
	}
	
	
/**
	//Typical getNext for nodes, used mainly for looping through linked list
	public Node<Type> getNext() {
		return next;
	}

	//Typical setNext for nodes, sets the links
	public void setNext(Node<Type> next) {
		this.next = next;
	}

	//get and set previous used for stack
	public Node<Type> getPrevious(){
		return previous;
	}
	
	public void setPrevious(Node<Type> previous){
		this.previous = previous;
	}
	//Gets the data inside the node, type is generic, defined by the data
	public Type getData() {
		return data;
	} **/
	
	
}
