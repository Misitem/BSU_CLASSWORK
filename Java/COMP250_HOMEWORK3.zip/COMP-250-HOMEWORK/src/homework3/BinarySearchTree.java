package homework3;
import homework3.Node;

public class BinarySearchTree {
	
	//Setting the main root, currRoot is used sometimes so the main root doesnt change
	Node<Integer> root;
	Node<Integer> currRoot = root;
	
	//Constructor for tree
	public BinarySearchTree() {
		this.root = null;
	}
	
	
/** Methods below are the ones called to perform specific actions
 * all the methods use recursion which are enclosed in their own methods found at the bottom
 * 
 */
	
	//Calls the recursive method that inserts a Node, also sets the root of the tree/subtree
	public void addNode(int key) {
		root = addNodeRecursion(root, key);
	}
	
	//Call the search recursion, the recursion returns either the matching node or null
	public boolean searchTree(int key) {
		currRoot = root;
		if(searchRecursion(currRoot, key) == null) {
			return false;
		}
		else{return true;
		}
	}
	
	//Finding min is easy, move current root to the left until you hit null
	public int findMin(){
		currRoot = root;
		while(currRoot.left != null) {
			currRoot = currRoot.left;
		}
		return currRoot.data;
	}
	
	//Same as min, except move to the right until you hit null
	public int findMax(){
		currRoot = root;
		while(currRoot.right != null) {
			currRoot = currRoot.right;
		}
		return currRoot.data;
	}
	

	
	//This begins the recursive call on the correct printing method
	public void printInOrder() {
		printInOrderRecursion(root);
	}
	
	public void printPostOrder() {
		printPostRecursion(root);
	}
	
	public void printPreOrder() {
		printPreRecursion(root);
	}
	
	public void printReverseOrder() {
		printPreRecursion(root);
	}

/** 
 * These methods are meant to be called recursively to traverse the tree for printing
 * when you recursively call, you're calling the print function on the subtree to either
 * the left or right, depending on which you specify.
 * 
 */
	
	public void  printInOrderRecursion(Node<Integer> root) {
		if (root != null) {
			printInOrderRecursion(root.left);		//Prints everything to the left of root
			System.out.println(root.data);			//Prints the root
			printInOrderRecursion(root.right);		//Prints everything to the right of root
		}
	}

	public void  printPostRecursion(Node<Integer> root) {
		if (root != null) {
			System.out.println(root.data);	
			printPostRecursion(root.right);		
			printPostRecursion(root.left);		
		}
	}
	
	public void  printPreRecursion(Node<Integer> root) {
		if (root != null) {
			System.out.println(root.data);
			printPreRecursion(root.left);		
			printPreRecursion(root.right);		
		}
	}
	
	public void  printReverseRecursion(Node<Integer> root) {
		if (root != null) {
			printReverseRecursion(root.right);		
			System.out.println(root.data);	
			printReverseRecursion(root.left);		
		}
	}
	
	//Recursion for inserting a node to the tree
	public Node<Integer> addNodeRecursion(Node<Integer> root, int key){
		
		//If the current root is null, set the inserted node to the root of the tree/subtree 
		if(root == null) {
			root = new Node<Integer>(key);
			return root;
		}
		
		//If the inserted value is less than the current roots value, place it to the left and call the same method on the subtree to the left.
		if(key < root.data) {
			root.left = addNodeRecursion(root.left, key); 
		} 
		
		//If value is greater than the root, place it to the right and call same recursive method on the subtree to the right
		else if( key > root.data) {
			root.right = addNodeRecursion(root.right, key);
		}
		
		//Return the root of the current tree, at first this is the original root, then it becomes root of the subtrees
		return root;
	}
	
	// Search uses advantage of recursion to search all subtrees
	public Node<Integer> searchRecursion(Node<Integer> root, int value) {
		
		//If data of current root equals the value, or if curr root is null return that root
	    if (root == null || root.data == value) {
	        return root;
	    }
	    
	    
	    //if curr data is less than input value, recursive call on left
	    if (root.data > value) {
	        return searchRecursion(root.left, value);
	    }
	    
	    //if value is greater than current root recursive call on the right
	    return searchRecursion(root.right, value);
	}
}
