package homework4;

import java.util.ArrayList;

public class HashAlgorithms {
	//Max table size
	final static int MAX_TABLE_SIZE = 15;
	//offset for collision
	final static int offset = 1;
	//Initializing Hash table list
	
	/** CHAINING HASH **/
	
	public static void chainingHash(int key[]) {

		//Initialize 2D array
		ArrayList<Integer> hashTable[] = new ArrayList[MAX_TABLE_SIZE];

		//New array for each index in hash table
		for (int i = 0; i < MAX_TABLE_SIZE; i++) {
			hashTable[i] = new ArrayList<Integer>();
		}

		//For all key, pass though hash1 and store in hashed location
		for (int i = 0; i < key.length; i++) {

			int hash1 = key[i] % MAX_TABLE_SIZE;
			hashTable[hash1].add(key[i]);

		}

		//print
		for (int i = 0; i < MAX_TABLE_SIZE; i++) {
			System.out.println(i + "\t" + hashTable[i]);		}
	}

	
	/** LINEAR PROBING HASH **/
	
	public static void linearProbing(int key[]) {

		ArrayList<Integer> hashTable[] = new ArrayList[MAX_TABLE_SIZE];

		//create Arraylist for each index for storing key
		for (int i = 0; i < MAX_TABLE_SIZE; i++) {
			hashTable[i] = new ArrayList<Integer>();
		
		}

		//For all key...
		for (int i = 0; i < key.length; i++) {

			//Store the hash if there is no collision
			int hash1result = key[i] % MAX_TABLE_SIZE;
			
			if (hashTable[hash1result].size() == 0) {
				hashTable[hash1result].add(key[i]);
				
			}
	
			//If there is a collision, offset by 1, then add to table 
			else {
				while (hashTable[hash1result].size() != 0) {
					hash1result = hash1result + offset;
					
				}
				hashTable[hash1result].add(key[i]);
				
			}

		}
		
		//print
		for (int i = 0; i < MAX_TABLE_SIZE; i++) {
			System.out.println(i + "\t" + hashTable[i]);
			
		}

	}

	
	/** DOUBLE HASH _ THE BEST KIND **/
	
	public static void doubleHashing(int key[]) {
		
		// Create a table
		int MAX_TABLE_SIZE = 15;
		
		ArrayList<Integer>[] hashTable = new ArrayList[MAX_TABLE_SIZE];

		for (int i = 0; i < MAX_TABLE_SIZE; i++) {
			hashTable[i] = new ArrayList<Integer>();
			
		}
		
		//loop through the keys
		for (int i = 0; i < key.length; i++) {

			// iterations/collisions starts at 0
			int iterations = 0;
			
			// equations for hash 1 and hash 2 and double hashing equation
			int hash1 = key[i] % MAX_TABLE_SIZE;
			int hash2 = key[i] % (MAX_TABLE_SIZE - 1);
			int hash = (hash1 + (iterations * hash2)) % MAX_TABLE_SIZE;

			// if  no collision, add to table
			if (hashTable[hash1].size() == 0) {
				hashTable[hash1].add(key[i]);

			}

			else {

				// for all entries in hash table, if collision, hash it again
				while (hashTable[hash].size() != 0) {
					
					iterations++; //Increment collisions
					
					hash = (hash1 + (iterations * hash2)) % MAX_TABLE_SIZE;
					
					if (hashTable[hash].size() == 0) {
						hashTable[hash].add(key[i]); // if yes then add it
						break;
					
					}
				}
			}
			iterations = 0; //Reset collisions
			
		}

		// print
		for (int i = 0; i < MAX_TABLE_SIZE; i++) {
			System.out.println(i + "\t" + hashTable[i]);
		
		}
	}
}	
