package homework4;

public class Main {

	public static void main(String[] args){
	
		
	//key array, otherwise would have to enter keys 1 at a time
	int[] key = {41, 24, 26, 62, 7, 6, 82, 74, 81, 93};
	
	System.out.println();
	System.out.println("Chaining Hash:");
	HashAlgorithms.chainingHash(key);
	System.out.println();
	
	System.out.println();
	System.out.println("Linear Probe Hash:");
	HashAlgorithms.linearProbing(key);

	
	System.out.println();
	System.out.println("Double Hash:");
	HashAlgorithms.doubleHashing(key);
	
	}

}
