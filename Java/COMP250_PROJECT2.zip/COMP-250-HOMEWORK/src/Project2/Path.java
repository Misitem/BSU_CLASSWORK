package Project2;


public class Path extends Graph {
	
	public static int shortestPath = 0;
	public static Vertex nextVertex;
	public Vertex temp1;

	public Path() {
		
	}
	//Place start in nextVertex for first recursive call, then call the recursive distance check
	public void findPath(Vertex start, Vertex end) {
		nextVertex = start;
		checkDistance(start, end);

		
		System.out.print("\nThe shortest path from " + start.ID + " to " + end.ID + " is: " + shortestPath );
	}
	

	public void checkDistance(Vertex v1, Vertex end) {
		int shortest = 100;

		//While the end is not reached...
		while(!nextVertex.getID().equals(end.getID())) {
			
			//for each edge on the edgelist of current vertex
			for(Edge edge : v1.edgeList) {

				//If current wait is less than shortest option, replace it
				if(edge.getWeight() < shortest) {
					shortest = edge.getWeight();
					
					//Hold a temp in case we need to move to next vertex
					temp1 = edge.getVertex2();
				}
				//nextVertex = edge.getVertex2();
				//shortestPath += shortest;
			}
			
			//Add shortest edge to total shortest path, move to the next vertex and call the method again
			shortestPath += shortest;
			nextVertex = temp1;
			checkDistance(nextVertex, end);
		}
			
	}
}
