package Project2;
import java.util.ArrayList;

public class Vertex {
	//List of edges for each vertex, and ID for each vertex
	ArrayList<Edge> edgeList = new ArrayList<Edge>();
	public String ID;

	//Constructor, creates vertex with char as identifier 
	public Vertex(String ID) {
		this.ID = ID;
		
	}
	
	public String getID() {
		return this.ID;
	}
	//To add an edge, take the two neighboring vertexes and set them as the two ends of the edge
	//Then set weight and add to the array of edges
	public void addEdge(Vertex neighbor1, Vertex neighbor2,  int weight) {
		Edge graphEdge = new Edge();
		graphEdge.setEnds(neighbor1, neighbor2);
		graphEdge.setWeight(weight);

		edgeList.add(graphEdge);

	}

	//This creates a char arraylist of neighbors and returns it
	public ArrayList<String> getNeighbors() {
		
		ArrayList<String> neighbors = new ArrayList<String>();
		
		//Loop through this vertex's list of edges and set neighbors to be any attached vertexes
		for(int i = 0; i < edgeList.size(); i++) {
			
			neighbors.add(edgeList.get(i).vertex2.ID);
		}
		//return the array of neighbors as array of chars
		return neighbors;
	}
}
