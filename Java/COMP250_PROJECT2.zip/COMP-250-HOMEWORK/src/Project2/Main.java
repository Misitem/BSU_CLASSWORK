package Project2;

public class Main {
	public static void main(String[] args) {
		Graph myGraph = new Graph();
	
		myGraph.addVertex("A");
		myGraph.addVertex("B");
		myGraph.addVertex("C");
		myGraph.addVertex("D");
		myGraph.addVertex("E");
		myGraph.addVertex("F");
	
		myGraph.addEdge("A", "B", 2);
		myGraph.addEdge("A", "D", 3);
		myGraph.addEdge("B", "C", 1);
		myGraph.addEdge("B", "D", 4);
		myGraph.addEdge("C", "D", 2);
		myGraph.addEdge("D", "F", 5);
		myGraph.addEdge("E", "F", 1);
		
		System.out.print("A's Neighbors are: ");
		myGraph.printNeighbors("A");
		System.out.print("B's Neighbors are: ");
		myGraph.printNeighbors("B");
		System.out.print("C's Neighbors are: ");
		myGraph.printNeighbors("C");
		System.out.print("D's Neighbors are: ");
		myGraph.printNeighbors("D");
		System.out.print("E's Neighbors are: ");
		myGraph.printNeighbors("E");
		System.out.print("F's Neighbors are: ");
		myGraph.printNeighbors("F");
		System.out.println();
		
		if(myGraph.isAdjacent("A", "B") == true) {
			System.out.println("A and B are adjacent");
		} else {System.out.println("Not adjacent");}
		
		System.out.println();
		
		if(myGraph.isAdjacent("F", "A") == true) {
			System.out.println("F and A are adjacent");
		} else {System.out.println("F and A are Not adjacent");}
		
		myGraph.bestPath("A", "C");
	}
}
