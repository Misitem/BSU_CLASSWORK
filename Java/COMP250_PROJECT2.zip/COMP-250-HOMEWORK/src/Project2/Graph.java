package Project2;

import java.util.ArrayList;

public class Graph {
	//Create an array for vertexs to make the graph
	ArrayList<Vertex> vList = new ArrayList<Vertex>();

	//To add a vertex, create a new one with the given name and add it to the arraylist
	public void addVertex(String vertex) {
		Vertex newVertex = new Vertex(vertex);
		vList.add(newVertex);
	}
	
	//takes String as input and finds the index of that vertex (Got some help on this one) 
	public Vertex findVertex(String vID) {
		
		//loop through array of vertexes, if entered String matches ID variable, return that vertex
		for (int i = 0; i < vList.size(); i++) {
			Vertex curr;
			curr = vList.get(i);
			
			if (curr.ID == vID) {
				return curr;
			}
		}
		return null;
	}
	
	//Find the two vertexes asked for, add an edge between them going both ways, give them weight
	public void addEdge(String vertex1, String vertex2, int weight) {
		Vertex tempV1 = findVertex(vertex1);
		Vertex tempV2 = findVertex(vertex2);
		tempV1.addEdge(tempV1, tempV2, weight);
		tempV2.addEdge(tempV2, tempV1, weight);
	}
	
	//boolean for if two vertexes are adjacent
	public boolean isAdjacent(String vertex1, String vertex2) {
		//Find the vertexes from the String given. 
		Vertex v1 = findVertex(vertex1);
		Vertex v2 = findVertex(vertex2);
		
		//For each edge in vertexs 1 list, compare to each edge in vertex 2 list, if they're connected return true
		for(Edge edge1 : v1.edgeList) {
			for(Edge edge2 : v2.edgeList) {
				
				//Vertex 1 will is one side of edge, vertex 2 is the other side, this is why we compare 1 to 2
				if(edge1.vertex1 == edge2.vertex2) {
					return true;
				}
			}
		}
		return false;
	}
	//To print, loop through all neighbors of given vertex as Strings and print them 
	public void printNeighbors(String vertexId) {
		Vertex currV;
		currV = findVertex(vertexId);
		for(String neighbor : currV.getNeighbors()) {
			System.out.print(neighbor + " ");
		}
		System.out.println();	//Spacer
	}
	
	public void bestPath(String start, String end) {
		Vertex startVertex = findVertex(start);
		Vertex endVertex = findVertex(end);
		Path newPath = new Path();
		newPath.findPath(startVertex, endVertex);
	}
	
}
